/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// Este componente não é mais utilizado. A chave de API agora está configurada no ambiente de implantação.
